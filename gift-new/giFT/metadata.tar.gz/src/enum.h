#include "meta.h"

unsigned char *decode_enum (Metadata * md);
Metadata *encode_enum (Metadata * md);
const char *get_tag_name (unsigned int type);
