#include "gift.h"
#include "meta.h"

int id_vorbis(FILE *fh, List **md_list);
