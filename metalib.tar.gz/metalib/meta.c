#include "meta.h"
#include "list.h"
#include "enum.h"
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>

static Metadata *new_tag(List **md_list) {
  Metadata *md=malloc(sizeof(md));
  if (!md) return 0;
  *md_list=list_append(*md_list,md);
  return md;
}

int add_tag_integer(List **md_list, int tag, unsigned long value) {
  Metadata *md=new_tag(md_list);
  if (!md) return 0;
  md->type=(tag &~META_MASK) | META_INTEGER;
  md->value.int_val=value;
  return 1;
}

int add_tag_string(List **md_list, int tag, unsigned char *value) {
  Metadata *md=new_tag(md_list);
  if (!md) return 0;
  md->type=(tag &~META_MASK) | META_STRING;
  md->value.str_val=value;
  return 1;
}

static int dump_tags_callback(void *data, void *unused) {
  Metadata *md=data;
  printf("tag 0x%02x\n",md->type);
  switch (md->type & META_MASK) {
  case META_INTEGER:
    printf("value: %lu\n",md->value.int_val);
    break;
  case META_STRING:
    printf("value: %s\n",md->value.str_val);
    break;
  }
  return 0;
}

void dump_tags(List *md_list) {
  list_foreach(md_list, dump_tags_callback, NULL);
}

unsigned long tag_to_integer(Metadata *md) {
  unsigned char *string;
  unsigned long value=0;

  switch (md->type & META_MASK) {
  case META_INTEGER:
    value=md->value.int_val;
    break;
  case META_STRING:
    value=strtoul(md->value.str_val,NULL,0);
    break;
  case META_ENUM:
    string=decode_enum(md);
    if (string) {
      value=strtoul(string,NULL,0);
      free(string);
    }
    break;
  default:
    fprintf(stderr, "Unknown meta tag type 0x%x\n",md->type);
    break;
  }
  return value;
}

unsigned char *tag_to_string(Metadata *md) {
  unsigned char *string=NULL;
  switch (md->type & META_MASK) {
  case META_INTEGER:
    /* should do some funky sprintf stuff here, but who cares? */
    break;
  case META_ENUM:
    string=decode_enum(md);
    break;
  case META_STRING:
    string=strdup(md->value.str_val);
    break;
  default:
    fprintf(stderr, "unknown tag type 0x%x\n",md->type);
  }
  return string;
}


int main(void) {
  List *md_list=NULL;
  if (!add_tag_integer(&md_list, TAG_BITRATE, 128))
    perror("add_tag_integer");

  if (!add_tag_string(&md_list, TAG_BITRATE, "foo"))
    perror("add_tag_string");

  dump_tags(md_list);
  printf("to_integer test: %lu\n", tag_to_integer(md_list->data));
  printf("to_string test: '%s'\n", tag_to_string(md_list->data));

  printf("to_integer test: %lu\n", tag_to_integer(list_next(md_list)->data));
  printf("to_string test: '%s'\n", tag_to_string(list_next(md_list)->data));
  return 0;
}

