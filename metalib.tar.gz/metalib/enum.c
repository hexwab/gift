#include "enum.h"
#include <stdlib.h> /* for NULL */
#include <stdio.h>

#if 0
const char *tag_enums[][]={
  NULL, /* filename (unused) */
  NULL, /* filesize */
  NULL, /* md5 */
  {
    "Unknown",
    "Audio",
    "Video",
    "Image",
    "Document",
    "Other"
  }, /* genre */
  NULL, /* bitrate */
  NULL, /* duration */
  NULL, /* Xres */
  NULL, /* Yres */
  NULL, /* title */
  NULL, /* artist */
  NULL, /* album */
  NULL, /* comment */
  NULL, /* year */
  NULL, /* track number */
  {
    "application/octet-stream",
    "audio/mpeg",
    "video/mpeg",
    "image/jpeg",
    "application/x-msvideo"
  } /* MIME type */
};
#endif

unsigned char *decode_enum(Metadata *md) {
  if ((md->type & META_MASK) != META_ENUM) {
    fprintf(stderr, "decode_enum called with non-enum tag 0x%x\n", md->type);
    return NULL;
  }
  return NULL;
#if 0
  unsigned int type=(md->type >> META_SHIFT);
  //  if (sizeof(tag_enums)/sizeof(tag_enums[0]));

  /* have to strdup as non-const strings are used elsewhere :( */
  //  return strdup();
#endif
}
