#include "meta.h"

unsigned char *decode_enum(Metadata *md);
