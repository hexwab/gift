#!/usr/bin/perl -w

package giFT::Interface;
require Exporter;
use strict;

use vars qw[@ISA @EXPORT_OK];

@ISA=qw[Exporter];
@EXPORT_OK=qw[serialize unserialize];

sub serialize(@) {
    my $out='';
    for my $this (@_) {
	$out.=_serialize($this,1).";\n";
    }
    $out;
}

sub _serialize {
    my $out='';
    my ($this,$hack)=@_;
    if (ref($this) eq 'HASH') {
	for my $key (sort keys %$this) {
	    my $val=$this->{$key};
	    $out.="$key ";
	    if (ref($val)) {
		my $tmp=_serialize($val,0);
		if ($hack){
		    $out.=$tmp;
		} else {
		    $out.="{$tmp}";
		}
	    } elsif (defined $val) {
		$val=~s/([]\[(){};\\])/\\$1/g;
		$out.="($val)";
	    }
	}
    }
    $out;
}

sub unserialize($) {
    local $_=shift;

    my ($out,$command,$val);
    
    $command=_key();
    $val=_value();
    
    $out=_unserialize();
    $out->{''}=$val if defined $val;

    ({$command=>$out},$_);
}    

sub _key {
    # allow hyphens too so we don't choke on various obscure meta tags
    s/^\s*(\w[\d\w-]*)\s*//s or die "Parse error";
    $1;
}

sub _value {
    my $val;

    if (s/^\(//s) {
	while(1) {
	    /\G\\./gc or
	    /\G[^])}]/gc or last;
	}

        die "Parse error" if !defined pos;

	$val=substr $_,0,pos;
	substr $_,0,1+pos,'';

	s/^\s*//;
	$val=~s/\\(.)/$1/g;
    }
    $val;
}

sub _unserialize {
    my %out=();

    my ($key,$val,$sub)=undef;

    while (!s/^\s*[;}]\s*//s) {
	undef $val;
	undef $sub;
	$key=_key();
	
	do {
	    if (defined (my $tmp=_value())) {
		$val=$tmp;
	    } elsif (s/^\{\s*//s) {
		$sub=_unserialize();
	    }
	    elsif (!/^[\w;}]/) {
		die "Parse error";
	    }
	} until /^[\w;}]/;
	
	if (defined $sub) {
	    $sub->{''}=$val if (defined $val);
	    $out{$key}=$sub;
	} else {
	    $out{$key}=$val;
	}
    }

    return \%out;
}

1;
__END__
=head1 NAME

giFT::Interface - giFT interface protocol

=head1 SYNOPSIS

  use giFT::Interface qw(serialize unserialize);

  my $hash={ search=>{ query=>"test" } });

  my $string=serialize($hash);

  # string now contains "search query (test);\n"

  my $newhash=unserialize($string);
 
  # $newhash is the same as the original $hash

=head1 DESCRIPTION

Parses giFT's interface protocol into a more usable form.

=over 4

=item B<($hash, $rest) = unserialize ($string)>

Takes a string from giFT and returns the first command as a hash reference, and the remainder of the string.

Item keys and values are stored as hash keys and values. Subitems have a hash reference instead; the value, if any, is stored in the key '' (null string) within the subhash.

=item B<serialize( $hash )>

Does the opposite of unserialize, i.e. returns a string corresponding to the given hash reference(s).

=head1 EXAMPLE

Calling unserialize() on the string

"COMMAND(number) ITEM(value) SUBCOMMAND(subvalue) { SUBITEM };"

would return the hash:
        {
          'COMMAND' => {
                         '' => 'number',
                         'ITEM' => 'value',
                         'SUBCOMMAND' => {
                                           '' => 'subvalue',
                                           'SUBITEM' => undef
                                         }
                       }
        }

=head1 NOTES

unserialize() may die with the error "Parse error" if it encounters anything unexpected. (This may be due to incorrect input, or simply an incomplete command.) For this reason, it's highly advisable to call it from within an eval block.

=head1 BUGS

unserialize() is very slow at processing large strings.

=head1 SEE ALSO

L<giFT::daemon>, L<giFT(1)>.

=head1 AUTHOR

Tom Hargreaves E<lt>HEx@freezone.co.ukE<gt>

=head1 LICENSE

Copyright 2003 by Tom Hargreaves.

This library is free software; you can redistribute it and/or modify it under th
e same terms as Perl itself. 

=cut
