package giFT::daemon;

use giFT::interface qw[serialize unserialize];

sub new {
    use IO::Socket::INET;
    my $socket=new IO::Socket::INET(
	PeerAddr=>'localhost',
	PeerPort=>1213,
	Blocking=>0
	) or die $!;
    $socket->blocking(0); # grrr... the Blocking=>0 above doesn't seem to work!

    bless {socket=>$socket, left=>'',wait=>1,debug=>$_[1]};
}

sub put {
    my ($self,@commands)=@_;
    
    for (@commands) {
	print {$self->{socket}} serialize($_);
    }
}

sub get {
    my $self=shift;

    $self->{socket}->recv(my $line,4096) and $self->{wait}=0;
    return undef if $self->{wait};

    $line=$self->{left}.$line if ($self->{left});
    my ($ret,$left)=eval { unserialize($line) };
    if (!$@) {
	$self->{left}=$left;
	return $ret ;
    }
    $self->{wait}=1;
    $self->{left}.=$line;
    
    undef;
}

sub DESTROY {
    my $self=shift;
    return close $self->{socket};
}

1;
