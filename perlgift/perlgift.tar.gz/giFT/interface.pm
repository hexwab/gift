#!/usr/bin/perl -w

package giFT::interface;
require Exporter;

@ISA=qw[Exporter];
@EXPORT_OK=qw[serialize unserialize];

sub serialize {
    my $out='';
    for my $this (@_) {
	$out.=_serialize($this,1).";\n";
    }
    $out;
}

sub _serialize {
    my $out='';
    my ($this,$hack)=@_;
    if (ref($this) eq 'HASH') {
	for my $key (sort keys %$this) {
	    my $val=$this->{$key};
	    $out.="$key ";
	    if (ref($val)) {
		my $tmp=_serialize($val,0);
		if ($hack){
		    $out.=$tmp;
		} else {
		    $out.="{$tmp}";
		}

	    } else {
		$val=~s/([]\[(){};\\])/\\$1/g;
		$out.="($val)";
	    }
	}
    }
    $out;
}

sub unserialize {
    my ($out,$command,$val);

    $_=shift;
    
    $command=_key();
    $val=_value();
    
    $out=_unserialize();
    $out->{''}=$val if defined $val;

    ({$command=>$out},$_);
}    

sub _key {
    s/^(\w[\d\w]*)\s*//s or die "Parse error";
    $1;
}

sub _value {
    my $val;

    if (s/^\(//) {
	while(1) {
	    /\G\\./gc or
	    /\G[^])}]/gc or last;
	}

	$val=substr $_,0,pos;
	substr $_,0,1+pos,'';

	s/^\s*//;
	$val=~s/\\(.)/$1/g;
    }
    $val;
}

sub _unserialize {
    my %out=();

    my ($key,$val,$sub)=undef;

    while (!s/^[;}]\s*//s) {
	undef $val;
	undef $sub;
	$key=_key();
	
	do {
	    if (defined (my $tmp=_value())) {
		$val=$tmp;
	    } elsif (s/^\{\s*//s) {
		$sub=_unserialize();
	    }
	    elsif (!/^[\w;}]/) {
		die "Parse error";
	    }
	} until /^[\w;}]/;
	
	if (defined $sub) {
	    $sub->{''}=$val if (defined $val);
	    $out{$key}=$sub;
	} else {
	    $out{$key}=$val;
	}
    }

    return \%out;
}

1;
